<script>
  import { onMount, onDestroy } from 'svelte';

	import LoremIpsum from './LoremIpsum.svelte'

	import Introduction from './Introduction.svelte'

  let activeStepIndex = 0;
  let observer;
  let scrollyRef;
  let flourishID = "2341003"; // L'ID de la story Flourish

// le texte des boites
	
  let stepsData = [
    { "text": "En 2010,<mark style='background-color: blue; color:white; padding: 2px; border-radius: 5px;''><strong> Bruxelles centre </mark> </strong> recense 1515 faits, alors qu'Uccle est � 465 et Ixelles d�passe � peine les 380 faits "},
	      { "text": "En 2015, <mark style='background-color: #4328E7; color:white; padding: 2px; border-radius: 5px;''> Bruxelles </mark> a atteint les 2070 faits, <mark style='background-color: #8D4FD7; color:white; padding: 2px; border-radius: 5px;''>Ixelles </mark> est pass� au-dessus <mark style='background-color: #FF6283; color:white; padding: 2px; border-radius: 5px;''>d'Uccle </mark>d�passant les 700 faits; Uccle en recense un peu plus de 450" },
		{ "text": "En 2020, la pand�mie n'a pas arrang� la situation : Bruxelles a connu un pic en atteignant pr�s de 3700 faits, alors qu'Ixelles se stabilise avec 800 faits et Uccle continue de d�croitre en ayant pr�s de 300 faits" },
		{ "text": "L'ann�e 2022 a montr� une tendance similaire dans ces 3 villes, puisque les chiffres ne cessent de d�croitre" },
  ];

	// Le "moteur" du scrollytelling qui utilise l'Intersection Observer API (en gros, le code observe ce qu'il y a � l'�cran)
	// �a on ne touche pas sinon tout se casse !

  onMount(() => {
    observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        const { target, isIntersecting } = entry;
        const index = Array.from(scrollyRef.querySelectorAll('.step')).indexOf(target);
        if (isIntersecting) {
          activeStepIndex = index;
        }
      });
    }, { threshold: 0.6 });

    const stepElements = scrollyRef.querySelectorAll('.step');
    stepElements.forEach(el => observer.observe(el));
  });

  onDestroy(() => {
    observer.disconnect();
  });
</script>

<h1>Nombre de faits li�s � la drogue � Bruxelles entre 2010 et 2022</h1>

<Introduction/>

<!-- si tu affiches la step_0, alors montre la slide_0 -->
<!-- si tu affiches la step_1, alors montre la slide_1 -->
<!-- si tu affiches la step_2, alors montre la slide_2 -->

<section bind:this={scrollyRef} class="section-container">

	  <div class="foreground">
    {#each stepsData as { text }, index}
      <div class="step" data-step={index}>
        <div class="step-content">
          <p>{@html text}</p> <!-- @html important pour que le css du script soit pris en compte-->
        </div>
      </div>
    {/each}
  </div>
	
  <div class="sticky-background">
    <!-- On affiche la slide Flourish en fonction de l'index -->
		<iframe src={`https://flo.uri.sh/story/${flourishID}/embed#slide-${activeStepIndex}`} title="Contenu interactif ou visuel" class="flourish-embed" frameborder="0" scrolling="no" style="width:100%;height:100vh;"></iframe>
  </div>


</section>


<style>

	/* Ici les valeurs pour l'ensemble de la page > 
	peut n�cessiter des modifs de couleurs dans Flourish 
	pour s'assurer que le graphe soit tjs bien visible (titre de graphique noir sur
	fond de page noir,�a ne se voit pas bien...*/

	:global(body) {
    background-color: white; 
		color: purple;
		font-family: 'Times New Roman', sans-serif; 
  }
	
	*{
		box-sizing: border-box;
	}
	.section-container {
    margin-top: 1em;
    text-align: center;
    display: flex;
    flex-direction: row; 
		
  }

  .sticky-background {
    position: sticky;
    top: 0;
    height: 100vh;
    flex: 0 1 60%;
    overflow: hidden;
    z-index: 1;
  }

  .foreground {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 0 1 40%;
		margin-bottom: 100vh;
  }

  .step {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    position: relative;
    z-index: 2;
    width: 100%;
  }

  .step-content {
    background-color: rgba(245, 245, 245, 0.8);
		box-shadow: 1px 1px 10px rgba(0, 0, 0, 0.2);
    color: black;
    border-radius: 10px;
		border: 5px solid skyblue;
    padding: 0.5rem 1rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
    z-index: 10;
    font-size: 1rem;
    text-align: left;
    width: 100%; 
    max-width: 500px; 
    margin: auto;
  }

	/* Pour adapter la vue en mobile: steps centr�es par dessus le graphique */

  @media screen and (max-width: 768px) {
    .section-container {
      flex-direction: column-reverse;
    }
    .sticky-background, .foreground {
      width: 100%; 
    }
    .foreground {
      margin-top: -80vh; 
    }
  }
</style>

